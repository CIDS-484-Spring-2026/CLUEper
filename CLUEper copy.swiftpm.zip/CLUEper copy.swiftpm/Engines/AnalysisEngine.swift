import Foundation

struct AnalysisEngine {
    
    static func analyze(
        rooms: [CardRow],
        suspects: [CardRow],
        weapons: [CardRow]
    ) -> AnalysisResult {
        
        return AnalysisResult(
            rooms: calculate(for: rooms),
            suspects: calculate(for: suspects),
            weapons: calculate(for: weapons)
        )
    }
    
    private static func calculate(for rows: [CardRow]) -> [String: Double] {
        
        var possibleCards: [String] = []
        
        for row in rows {
            // If nobody has this card, it's a candidate for the envelope
            let someoneHasIt = row.states.contains { $0 == .has }
            
            if !someoneHasIt {
                possibleCards.append(row.name)
            }
        }
        
        let probability = possibleCards.isEmpty
            ? 0
            : 1.0 / Double(possibleCards.count)
        
        var results: [String: Double] = [:]
        
        for row in rows {
            if possibleCards.contains(row.name) {
                results[row.name] = probability
            } else {
                results[row.name] = 0
            }
        }
        
        return results
    }
}
