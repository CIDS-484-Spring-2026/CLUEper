import SwiftUI

struct AnalysisRowView: View {
    
    let result: AnalysisResult
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                
                bestAccusationCard
                
                playerStatusCard
                
                probabilityContent
            }
            .padding()
        }
    }
}

//Best Accusation Card
extension AnalysisRowView {
    
    var bestAccusationCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            
            HStack(spacing: 10) {
                Image(systemName: "lightbulb.fill")
                    .foregroundColor(.yellow)
                    .padding(8)
                    .background(Color.yellow.opacity(0.15))
                    .cornerRadius(10)
                
                Text("Best Accusation to Make")
                    .foregroundColor(.white)
                    .font(.headline)
            }
            
            Text("Most likely correct combination based on your notes")
                .foregroundColor(.white.opacity(0.6))
                .font(.caption)
            
            accusationRow(title: "Suspect",
                          value: top(result.suspects),
                          color: .red)
            
            accusationRow(title: "Weapon",
                          value: top(result.weapons),
                          color: .orange)
            
            accusationRow(title: "Room",
                          value: top(result.rooms),
                          color: .blue)
        }
        .padding()
        .background(Color.white.opacity(0.05))
        .cornerRadius(18)
    }
    
    func accusationRow(title: String, value: String, color: Color) -> some View {
        HStack {
            Text(title)
                .foregroundColor(.white.opacity(0.7))
            
            Spacer()
            
            Text(value)
                .foregroundColor(color)
                .fontWeight(.semibold)
        }
        .padding()
        .background(Color.white.opacity(0.05))
        .cornerRadius(14)
    }
}

// MARK: - Player Status Card
extension AnalysisRowView {
    
    var playerStatusCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            
            HStack(spacing: 10) {
                Image(systemName: "person.2.fill")
                    .foregroundColor(.blue)
                    .padding(8)
                    .background(Color.blue.opacity(0.15))
                    .cornerRadius(10)
                
                Text("Player Status")
                    .foregroundColor(.white)
                    .font(.headline)
            }
            
            Text("How close each opponent is to knowing the answer")
                .foregroundColor(.white.opacity(0.6))
                .font(.caption)
            
            ForEach(playerStatuses(), id: \.name) { player in
                playerRow(player)
            }
        }
        .padding()
        .background(Color.white.opacity(0.05))
        .cornerRadius(18)
    }
    
    func playerRow(_ player: PlayerStatus) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            
            HStack {
                Text(player.name)
                    .foregroundColor(.white)
                
                Spacer()
                
                Text(player.label)
                    .foregroundColor(.green)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Color.green.opacity(0.2))
                    .cornerRadius(10)
            }
            
            GeometryReader { geo in
                Capsule()
                    .fill(Color.white.opacity(0.1))
                    .overlay(
                        Capsule()
                            .fill(Color.green)
                            .frame(width: geo.size.width * player.progress),
                        alignment: .leading
                    )
            }
            .frame(height: 6)
            
            Text(player.detail)
                .foregroundColor(.white.opacity(0.5))
                .font(.caption2)
        }
    }
}

// Probability Card
extension AnalysisRowView {
    
    var probabilityContent: some View {
        VStack(alignment: .leading, spacing: 16) {
            
            HStack(spacing: 10) {
                Image(systemName: "envelope.open.fill")
                    .foregroundColor(.purple)
                    .padding(8)
                    .background(Color.purple.opacity(0.15))
                    .cornerRadius(10)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("Envelope Probabilities")
                        .font(.headline)
                        .foregroundColor(.white)
                    
                    Text("Likelihood each card is in the envelope")
                        .foregroundColor(.white.opacity(0.6))
                        .font(.caption)
                }
            }
            
            VStack(spacing: 18) {
                probabilitySection(
                    title: "SUSPECTS",
                    data: result.suspects,
                    color: .red
                )
                
                probabilitySection(
                    title: "WEAPONS",
                    data: result.weapons,
                    color: .orange
                )
                
                probabilitySection(
                    title: "ROOMS",
                    data: result.rooms,
                    color: .blue
                )
            }
        }
        .padding()
        .background(Color.white.opacity(0.05))
        .cornerRadius(18)
    }
    
    func probabilitySection(title: String,
                            data: [String: Double],
                            color: Color) -> some View {
        
        VStack(alignment: .leading, spacing: 12) {
            
            Text(title)
                .foregroundColor(color)
                .font(.caption.bold())
                .opacity(0.9)
            
            ForEach(sortedKeys(data), id: \.self) { key in
                
                let value = data[key] ?? 0
                
                HStack {
                    
                    Text(key)
                        .foregroundColor(.white)
                        .frame(width: 120, alignment: .leading)
                    
                    GeometryReader { geo in
                        ZStack(alignment: .leading) {
                            
                            Capsule()
                                .fill(Color.white.opacity(0.1))
                            
                            Capsule()
                                .fill(color)
                                .frame(width: geo.size.width * value)
                        }
                    }
                    .frame(height: 8)
                    
                    Text("\(Int(value * 100))%")
                        .foregroundColor(color)
                        .frame(width: 40, alignment: .trailing)
                }
                .padding(10)
                .background(Color.white.opacity(0.04)) // ✅ row card style
                .cornerRadius(10)
            }
        }
    }
    
    func sortedKeys(_ dict: [String: Double]) -> [String] {
        dict.keys.sorted()
    }
}

// MARK: - Helpers
extension AnalysisRowView {
    
    func top(_ dict: [String: Double]) -> String {
        dict.max(by: { $0.value < $1.value })?.key ?? "-"
    }
    
    struct PlayerStatus {
        let name: String
        let progress: Double
        let label: String
        let detail: String
    }
    
    func playerStatuses() -> [PlayerStatus] {
        return [
            PlayerStatus(name: "Player 1", progress: 0.1, label: "Low Threat", detail: "20 envelope cards still unknown to them"),
            PlayerStatus(name: "Player 2", progress: 0.1, label: "Low Threat", detail: "20 envelope cards still unknown to them"),
            PlayerStatus(name: "Player 3", progress: 0.1, label: "Low Threat", detail: "20 envelope cards still unknown to them"),
            PlayerStatus(name: "Player 4", progress: 0.1, label: "Low Threat", detail: "20 envelope cards still unknown to them")
        ]
    }
}
