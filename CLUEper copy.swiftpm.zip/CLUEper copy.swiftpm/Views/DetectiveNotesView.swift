import SwiftUI

//Main View
struct DetectiveNotesView: View {
    
    let players: [String]
    let yourCards: [String]
    let yourPlayerIndex: Int
    
    @State private var didSave = false
    
    @State var rooms: [CardRow] = []
    @State var suspects: [CardRow] = []
    @State var weapons: [CardRow] = []
    @State var logs: [RoundLog] = []
    @State var selectedTab: NotesTab = .notes
    
    @State var showingAddLog = false
    
    var body: some View {
        ZStack {
            
            Color.black
                .ignoresSafeArea()
                .navigationBarHidden(true)
            
            VStack(spacing: 0) {
                
                header
                
                Group {
                    switch selectedTab {
                    case .notes:
                        roundView
                    case .analysis:
                        analysisView
                    case .log:
                        logView
                    }
                }
                
                Spacer(minLength: 6)
                
                if selectedTab == .notes {
                    legend
                        .padding(.vertical, 8)
                }
            }
            
            if showingAddLog {
                VStack {
                    Spacer()
                    
                    VStack(spacing: 12) {
                        
                        Capsule()
                            .frame(width: 40, height: 5)
                            .foregroundColor(.gray.opacity(0.5))
                            .padding(.top, 8)
                        
                        RoundLogEntryView(
                            players: players,
                            you: players[yourPlayerIndex]
                        ) { newLog in
                            logs.append(newLog)
                            applyLog(newLog)
                            showingAddLog = false
                        }
                    }
                    .frame(height: 350)
                    .padding(.bottom, 20)
                    .background(Color(.systemBackground))
                    .cornerRadius(20)
                    .ignoresSafeArea(edges: .bottom)
                }
                .animation(.easeInOut, value: showingAddLog)
            }
        }
        .onAppear { setupData() }
    }
}

// MARK: - Analysis Engine Hook
extension DetectiveNotesView {
    var analysis: AnalysisResult {
        AnalysisEngine.analyze(
            rooms: rooms,
            suspects: suspects,
            weapons: weapons
        )
    }
}

// MARK: - Sections / Grid
extension DetectiveNotesView {
    
    func section(title: String, rows: Binding<[CardRow]>) -> some View {
        VStack(spacing: 14) {
            
            HStack {
                Rectangle().fill(Color.white.opacity(0.25)).frame(height: 1)
                
                Text(title)
                    .foregroundColor(.white.opacity(0.9))
                    .font(.caption.bold())
                    .padding(.horizontal, 8)
                
                Rectangle().fill(Color.white.opacity(0.25)).frame(height: 1)
            }
            .padding(.horizontal, 6)
            
            ForEach(rows) { $row in
                rowView($row)
            }
        }
    }
    
    func rowView(_ row: Binding<CardRow>) -> some View {
        GeometryReader { geo in
            
            let nameWidth = geo.size.width * 0.28
            let cellWidth = (geo.size.width - nameWidth - 4) / CGFloat(players.count)
            
            HStack(spacing: 0) {
                
                Text(row.wrappedValue.name)
                    .foregroundColor(.white)
                    .frame(width: nameWidth, alignment: .leading)
                
                ForEach(row.wrappedValue.states.indices, id: \.self) { index in
                    cellView(state: row.wrappedValue.states[index])
                        .frame(width: cellWidth)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            row.wrappedValue.states[index] =
                                row.wrappedValue.states[index].next()
                        }
                }
            }
        }
        .frame(height: 42)
    }
}

// MARK: - Cell
extension DetectiveNotesView {
    
    func cellView(state: CellState) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 5)
                .stroke(Color.white.opacity(0.35), lineWidth: 1.6)
            
            switch state {
            case .unknown:
                EmptyView()
            case .has:
                Image(systemName: "checkmark").foregroundColor(.green)
            case .no:
                Image(systemName: "xmark").foregroundColor(.red)
            case .maybe:
                Text("?").foregroundColor(.yellow)
            }
        }
        .frame(width: 26, height: 26)
    }
}

// MARK: - Header + Tabs
extension DetectiveNotesView {
    
    var header: some View {
        VStack(spacing: 12) {
            
            HStack {
                
                Button {
                    print("Home tapped")
                } label: {
                    Image(systemName: "house.fill")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.white)
                        .padding(10)
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(10)
                }
                
                Spacer()
                
                HStack(spacing: 6) {
                    Text("CLUEper")
                        .font(.system(size: 26, weight: .semibold))
                    
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 18, weight: .semibold))
                }
                .foregroundColor(.white)
                
                Spacer()
                
                Button {
                    didSave = true
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                        withAnimation { didSave = false }
                    }
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: didSave ? "checkmark.circle.fill" : "externaldrive.fill")
                        Text(didSave ? "Saved" : "Save")
                    }
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(didSave ? .green : .white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(10)
                }
            }
            .padding(.horizontal, 16)
            
            Rectangle().fill(Color.white.opacity(0.15)).frame(height: 1)
            
            //Tabs
            HStack(spacing: 12) {
                tabButton("Notes", icon: "square.grid.2x2", tab: .notes, color: .orange)
                tabButton("Analysis", icon: "brain.head.profile", tab: .analysis, color: .purple)
                tabButton("Log", icon: "list.bullet", tab: .log, color: .gray)
                
                Button {
                    showingAddLog = true
                } label: {
                    Text("+Log")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 12)
                        .background(Color.red)
                        .cornerRadius(14)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            
            Rectangle().fill(Color.white.opacity(0.15)).frame(height: 1)
        }
    }
    
   
    func tabButton(_ title: String,
                   icon: String,
                   tab: NotesTab,
                   color: Color) -> some View {

        let isSelected = selectedTab == tab

        return Button {
            selectedTab = tab
        } label: {
            HStack(spacing: 6) {
                Image(systemName: icon)
                Text(title)
            }
            .font(.system(size: 15, weight: .semibold))
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(color.opacity(isSelected ? 1 : 0.6))
            .cornerRadius(14)
        }
    }
}

// MARK: - Legend
extension DetectiveNotesView {
    
    var legend: some View {
        HStack(spacing: 20) {
            Text("✔ Yes").foregroundColor(.green)
            Text("✘ No").foregroundColor(.red)
            Text("? Maybe").foregroundColor(.yellow)
            Text("□ Unknown").foregroundColor(.white)
        }
        .font(.caption2)
    }
}

// MARK: - Data Setup
extension DetectiveNotesView {
    
    func setupData() {
        rooms = ClueCards.rooms.map {
            CardRow(name: $0, states: initialStates(for: $0))
        }
        
        suspects = ClueCards.suspects.map {
            CardRow(name: $0, states: initialStates(for: $0))
        }
        
        weapons = ClueCards.weapons.map {
            CardRow(name: $0, states: initialStates(for: $0))
        }
    }
    
    func initialStates(for card: String) -> [CellState] {
        players.enumerated().map { index, _ in
            
            if yourCards.contains(card) {
                return index == yourPlayerIndex ? .has : .no
            }
            
            return index == yourPlayerIndex ? .no : .unknown
        }
    }
}

// MARK: - Apply Log
extension DetectiveNotesView {
    
    func applyLog(_ log: RoundLog) {
        if let shownCard = log.shownCard,
           let playerIndex = players.firstIndex(of: log.shownBy ?? "") {
            
            update(card: shownCard, playerIndex: playerIndex)
        }
    }
    
    func update(card: String, playerIndex: Int) {
        
        func updateRow(_ rows: inout [CardRow]) {
            if let i = rows.firstIndex(where: { $0.name == card }) {
                for index in rows[i].states.indices {
                    rows[i].states[index] =
                        (index == playerIndex) ? .has : .no
                }
            }
        }
        
        updateRow(&suspects)
        updateRow(&weapons)
        updateRow(&rooms)
    }
}

// MARK: - Column Header
extension DetectiveNotesView {
    
    var columnHeader: some View {
        GeometryReader { geo in
            
            let nameWidth = geo.size.width * 0.28
            let cellWidth = (geo.size.width - nameWidth - 4) / CGFloat(players.count)
            
            HStack(spacing: 0) {
                
                Color.clear
                    .frame(width: nameWidth)
                
                ForEach(players.indices, id: \.self) { index in
                    Text(players[index])
                        .foregroundColor(playerColor(for: index))
                        .font(.caption.weight(.bold))
                        .frame(width: cellWidth)
                }
            }
        }
        .frame(height: 30)
    }
    
    func playerColor(for index: Int) -> Color {
        let colors: [Color] = [.red, .blue, .green, .yellow, .purple, .orange]
        return colors[index % colors.count]
    }
}
