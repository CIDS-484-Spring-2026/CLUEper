import SwiftUI

// Model
struct RoundLog: Identifiable, Hashable {
    let id = UUID()
    
    let player: String
    let suspect: String
    let weapon: String
    let room: String
    
    let shownBy: String?
    let shownCard: String?
}


// Main View
struct RoundLogEntryView: View {
    
    let players: [String]
    let you: String
    var onSave: (RoundLog) -> Void
    
    // Step
    @State private var step = 0
    
    // Question selections
    @State private var selectedPlayer = ""
    @State private var suspect = ""
    @State private var weapon = ""
    @State private var room = ""
    @State private var shownBy = ""
    @State private var shownCard = ""
    
    // Data
    private let suspects = [
        "Miss Scarlet","Colonel Mustard","Mrs. White",
        "Mr. Green","Mrs. Peacock","Professor Plum"
    ]
    
    private let weapons = [
        "Knife","Candlestick","Revolver",
        "Rope","Lead Pipe","Wrench"
    ]
    
    private let rooms = [
        "Kitchen","Ballroom","Conservatory",
        "Dining Room","Library","Study"
    ]
    
    var allCards: [String] {
        suspects + weapons + rooms
    }
    
    var totalSteps: Int {
        selectedPlayer == you ? 6 : 5
    }
    
    // Body
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack(spacing: 20) {
                
                ProgressView(value: Double(step), total: Double(totalSteps - 1))
                    .tint(.red)
                
                Spacer()
                
                stepView
                    .transition(.opacity.combined(with: .slide))
                    .animation(.easeInOut(duration: 0.25), value: step)
                
                Spacer()
                
                navButtons
            }
            .padding()
        }
    }
}


//Step Views
extension RoundLogEntryView {
    
    @ViewBuilder
    var stepView: some View {
        
        switch step {
            
        case 0:
            block("Who is guessing?") {
                playerGrid(selection: $selectedPlayer)
            }
            
        case 1:
            block("Which Room?") {
                cardGrid(rooms, selection: $room)
            }
            
        case 2:
            block("Which Weapon?") {
                cardGrid(weapons, selection: $weapon)
            }
            
        case 3:
            block("Which Suspect?") {
                cardGrid(suspects, selection: $suspect)
            }
            
        case 4:
            if selectedPlayer == you {
                block("What were you shown?") {
                    cardGrid([suspect, weapon, room, "None"], selection: $shownCard)
                }
            } else {
                block("Who showed a card?") {
                    playerGrid(selection: $shownBy, allowNone: true)
                }
            }
            
        case 5:
            block("Who showed a card?") {
                playerGrid(selection: $shownBy, allowNone: true)
            }
            
        default:
            EmptyView()
        }
    }
}


// Block Layout
extension RoundLogEntryView {
    
    func block<Content: View>(_ title: String,
                              @ViewBuilder content: () -> Content) -> some View {
        VStack(spacing: 22) {
            Text(title)
                .font(.title2.bold())
                .foregroundColor(.white)
            
            content()
        }
    }
}


// Player Grid
extension RoundLogEntryView {
    
    func playerGrid(selection: Binding<String>,
                    allowNone: Bool = false) -> some View {
        
        let options = allowNone ? players + ["None"] : players
        
        return LazyVGrid(columns: [.init(.adaptive(minimum: 120))], spacing: 12) {
            
            ForEach(options, id: \.self) { name in
                
                Button {
                    selection.wrappedValue = name
                } label: {
                    HStack {
                        Text(name)
                            .font(.caption.weight(.semibold))
                            .foregroundColor(.white)
                        
                        Spacer()
                        
                        if name == you && selection.wrappedValue == name {
                            Text("You")
                                .font(.caption)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.black.opacity(0.3))
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .padding(.horizontal, 12)
                    .background(
                        selection.wrappedValue == name
                        ? playerColor(name)
                        : Color.white.opacity(0.08)
                    )
                    .cornerRadius(12)
                }
            }
        }
    }
}


// Card Grid
extension RoundLogEntryView {
    
    func cardGrid(_ items: [String],
                  selection: Binding<String>) -> some View {
        
        LazyVGrid(columns: [.init(.adaptive(minimum: 120))], spacing: 12) {
            
            ForEach(items, id: \.self) { item in
                
                let selected = selection.wrappedValue == item
                
                Button {
                    selection.wrappedValue = item
                } label: {
                    Text(item)
                        .font(.caption.weight(.medium))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(
                            selected
                            ? colorForCard(item)
                            : Color.white.opacity(0.08)
                        )
                        .cornerRadius(12)
                }
            }
        }
    }
}


// Navigation
extension RoundLogEntryView {
    
    var navButtons: some View {
        HStack {
            
            if step > 0 {
                Button("Back") { step -= 1 }
                    .foregroundColor(.white)
            }
            
            Spacer()
            
            Button(step == totalSteps - 1 ? "Save" : "Next") {
                
                if step == totalSteps - 1 {
                    save()
                } else {
                    step += 1
                }
            }
            .foregroundColor(.white)
            .padding(.horizontal, 26)
            .padding(.vertical, 12)
            .background(canContinue ? Color.red : Color.gray)
            .cornerRadius(14)
            .disabled(!canContinue)
        }
    }
}


// Logic
extension RoundLogEntryView {
    
    var canContinue: Bool {
        switch step {
        case 0: return !selectedPlayer.isEmpty
        case 1: return !room.isEmpty
        case 2: return !weapon.isEmpty
        case 3: return !suspect.isEmpty
        case 4:
            return selectedPlayer == you
                ? !shownCard.isEmpty
                : !shownBy.isEmpty
        case 5:
            return !shownBy.isEmpty
        default:
            return false
        }
    }
    
    func save() {
        let log = RoundLog(
            player: selectedPlayer,
            suspect: suspect,
            weapon: weapon,
            room: room,
            shownBy: shownBy == "None" ? nil : shownBy,
            shownCard: (shownCard.isEmpty || shownCard == "None") ? nil : shownCard
        )
        
        onSave(log)
    }
    
    func playerColor(_ name: String) -> Color {
        let index = players.firstIndex(of: name) ?? 0
        let colors: [Color] = [.red, .blue, .green, .yellow, .purple, .orange]
        return colors[index % colors.count]
    }
    
    func colorForCard(_ card: String) -> Color {
        if weapons.contains(card) {
            return .orange
        } else if rooms.contains(card) {
            return .blue
        } else {
            return .red
        }
    }
}
